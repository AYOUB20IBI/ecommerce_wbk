
import {
  ForbiddenException,
  Inject,
  Injectable,
  InternalServerErrorException,
} from '@nestjs/common';

import { drizzle } from 'drizzle-orm/node-postgres';
import { eq, sql } from 'drizzle-orm';

import { DATABASE } from '../../database/database.provider';

import {
  adminUserRoles,
  adminUsers,
  roles,
} from '../../database/schema/auth.schema';

import {
  DEFAULT_MEDIA_SETTINGS,
  mediaSettingsSchema,
  type MediaSettingsInput,
} from './media-settings.dto';

type SettingsRow = {
  configuration: unknown;
  updated_at: Date;
};

@Injectable()
export class MediaSettingsService {
  constructor(
    @Inject(DATABASE)
    private readonly db: ReturnType<typeof drizzle>,
  ) {}

  async assertAdmin(adminId: string): Promise<void> {
    const assignedRoles = await this.db
      .select({
        name: roles.name,
        active: adminUsers.isActive,
      })
      .from(adminUserRoles)
      .innerJoin(
        roles,
        eq(adminUserRoles.roleId, roles.id),
      )
      .innerJoin(
        adminUsers,
        eq(adminUserRoles.userId, adminUsers.id),
      )
      .where(eq(adminUserRoles.userId, adminId));

    const isAdmin = assignedRoles.some((role) => {
      if (!role.active) return false;

      const name = role.name
        .trim()
        .toLowerCase()
        .replace(/[_-]+/g, ' ');

      return name === 'admin' || name === 'super admin';
    });

    if (!isAdmin) {
      throw new ForbiddenException({
        success: false,
        message: 'Admin role required.',
      });
    }
  }

  private async getRow(): Promise<SettingsRow | null> {
    const result = await this.db.execute<SettingsRow>(sql`
      SELECT configuration, updated_at
      FROM media_upload_settings
      WHERE id = 1
      LIMIT 1
    `);

    return result.rows[0] ?? null;
  }

  async getConfiguration(): Promise<MediaSettingsInput> {
    const row = await this.getRow();

    if (!row) {
      throw new InternalServerErrorException({
        success: false,
        message: 'Media settings have not been initialized.',
      });
    }

    const validated = mediaSettingsSchema.safeParse(
      row.configuration,
    );

    if (!validated.success) {
      throw new InternalServerErrorException({
        success: false,
        message: 'Stored media settings are invalid.',
      });
    }

    return validated.data;
  }

  async getForAdmin(adminId: string) {
    await this.assertAdmin(adminId);

    const row = await this.getRow();
    const configuration = await this.getConfiguration();

    return {
      configuration,
      updatedAt: row?.updated_at ?? null,
    };
  }

  async updateForAdmin(
    adminId: string,
    input: MediaSettingsInput,
  ) {
    await this.assertAdmin(adminId);

    const configuration = mediaSettingsSchema.parse(
      input,
    );

    const payload = JSON.stringify(configuration);

    const result = await this.db.execute<SettingsRow>(sql`
      INSERT INTO media_upload_settings (
        id,
        configuration,
        updated_by,
        updated_at
      )
      VALUES (
        1,
        ${payload}::jsonb,
        ${adminId}::uuid,
        NOW()
      )
      ON CONFLICT (id)
      DO UPDATE SET
        configuration = EXCLUDED.configuration,
        updated_by = EXCLUDED.updated_by,
        updated_at = NOW()
      RETURNING configuration, updated_at
    `);

    if (!result.rows[0]) {
      throw new InternalServerErrorException({
        success: false,
        message: 'Media settings update failed.',
      });
    }

    return {
      configuration,
      updatedAt: result.rows[0].updated_at,
    };
  }
}
